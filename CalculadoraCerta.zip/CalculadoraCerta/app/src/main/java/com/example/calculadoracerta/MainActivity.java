package com.example.calculadoracerta;

        import android.app.Activity;
        import android.support.v7.app.AppCompatActivity;
        import android.os.Bundle;
        import android.view.View;
        import android.widget.Button;
        import android.widget.EditText;

public class MainActivity extends Activity {



    double resultado,n1, n2;

    EditText txt1, txt2, res;
    Button som, sub, div, mul, por;


    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        som      = (Button)   findViewById(R.id.som);
        sub    = (Button)   findViewById(R.id.sub);
        div     = (Button)   findViewById(R.id.div);
        mul = (Button)   findViewById(R.id.mul);
        txt1    = (EditText) findViewById(R.id.txt1);
        txt2    = (EditText) findViewById(R.id.txt2);
        res  = (EditText) findViewById(R.id.res);
        por = (Button)   findViewById(R.id.por);

        som.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                n1 = Double.parseDouble(txt1.getText().toString());
                n2 = Double.parseDouble(txt2.getText().toString());

                resultado = n1+n2;
                res.setText(String.valueOf(res));
            }
        });

        sub.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                n1 = Double.parseDouble(txt1.getText().toString());
                n2 = Double.parseDouble(txt2.getText().toString());

                resultado = n1-n2;

                res.setText(String.valueOf(resultado));
            }
        });

        div.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                n1 = Double.parseDouble(txt1.getText().toString());
                n2 = Double.parseDouble(txt2.getText().toString());

                resultado = n1/n2;

                res.setText(String.valueOf(resultado));
            }
        });

        mul.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                n1 = Double.parseDouble(txt1.getText().toString());
                n2 = Double.parseDouble(txt2.getText().toString());

                resultado = n1*n2;
                res.setText(String.valueOf(resultado));
                res.setText(String.valueOf(resultado));

            }
        });


        por.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                n1 = Double.parseDouble(txt1.getText().toString());
                n2 = Double.parseDouble(txt2.getText().toString());

                resultado = n1 = n2 *0.10;
                res.setText(String.valueOf(resultado));


            }
        });

    }
}