package com.example.trabalho;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button b1 = (Button) findViewById(R.id.bt_calcular);

        b1.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {

                EditText consumo = (EditText) findViewById(R.id.edt_consumo);
                EditText couvert = (EditText) findViewById(R.id.edt_couvert_artistico);
                EditText div = (EditText) findViewById(R.id.edt_dividir);
                EditText taxa = (EditText) findViewById(R.id.edt_couvert_artistico);
                EditText conta = (EditText) findViewById(R.id.edt_conta_total);
                EditText valor = (EditText) findViewById(R.id.edt_consumo);


                double taxaServico = Double.parseDouble(consumo.getText().toString()) * 0.10;
                double contaTotal = Double.parseDouble(couvert.getText().toString()) + Double.parseDouble(consumo.getText().toString()) + taxaServico;
                double contaPessoa = contaTotal / Double.parseDouble(div.getText().toString());

                taxa.setText((int) taxaServico);


            }
        });

    }
}
